<?php
/**
 * Auteur: romain.ssr@eduge.ch
 * Date : 08.05.2018
 * projet: SimpleTab
 * description: Variables pour la connection à la base de données
 */
define ('EDB_DBTYPE', "mysql");
define ('EDB_HOST', "localhost");
define ('EDB_PORT', "3306");
define ('EDB_DBNAME', "simpletab");
define ('EDB_USER', "root");
define ('EDB_PASS', "root");

?>