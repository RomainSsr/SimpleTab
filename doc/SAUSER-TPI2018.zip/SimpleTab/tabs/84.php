<?php 
$xmlstr = <<<XML
<?xml version = "1.0" encoding="UTF-8" standalone="yes" ?>
<tabs>
     <metadata>
            <title> Photograph </title>
            <author>Ed Sheeran</author>
            <tuning>E A D G B E</tuning>
            <capo></capo>
            <key></key>
            <level> Facile</level>
     </metadata>
     <corpse>
     [Intro]

D   Bm   A   G


[Verse]

           D
Loving can hurt
           Bm
Loving can hurt sometimes
             A                          G 
But it's the only thing that I know
             D
When it gets hard
                    Bm
You know it can get hard sometimes
          A                                 G
It is the only thing that makes us feel alive


[Pre-Chorus]

Bm                      G
We keep this love in a photograph
D                       A
We make these memories for ourselves
          Bm           
Where our eyes are never closing
     G
Our hearts were never broken
     D                         A
And times forever frozen still


[Chorus]

           D
So you can keep me inside the pocket of your
A
Ripped jeans holding me closer till our
Bm                             G
Eyes meet, you won't ever be alone
                         D
Wait for me to come home


[Verse]

            D
Loving can heal
           Bm
Loving can mend your soul
             A                         G
And it's the only thing that I know
                    D
I swear it will get easier
                           Bm
remember that with every piece of ya
             A                                   G
It is the only thing we take with us when we die


[Pre-Chorus]

Bm                      G
We keep this love in a photograph
D                       A
We make these memories for ourselves
          Bm           
Where our eyes are never closing
     G
Our hearts were never broken
     D                      A
And times forever frozen still


[Chorus]

           D
So you can keep me inside the pocket of your
A
Ripped jeans holding me closer till our
Bm                               G
Eyes meet, you won't ever be alone


[Bridge]

           D
And if you hurt me that's ok baby, only
A 
Words bleed inside these pages you just
Bm                              G
Hold me and I won't ever let you go


[Interlude]

                     Bm
Wait for me to come home
                     G       
Wait for me to come home
                     D
Wait for me to come home
                     A
Wait for me to come home


[Outro]

           D                               
Oh you can fit me inside the necklace you got when you were
A           
16 next to your heartbeat where I 
Bm                                    G
Should be, keep it deep within your soul
           D
And if you hurt me that's ok baby only 
A 
Words bleed inside these pages you just
Bm                              G
Hold me and I won't ever let you go
          D                 
When I'm away I will remember how you
A                                      Bm
Kissed me under the lamp post back on sixth street 
                                 G
Hearing you whisper through the phone
                     D
Wait for me to come home



     </corpse>
</tabs>
XML;
?>